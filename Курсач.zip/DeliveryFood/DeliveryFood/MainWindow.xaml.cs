﻿using DeliveryFood.Classes;
using DeliveryFood.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DeliveryFood
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;

            Globals.DataProvider = new MySqlDataProvider();
            MenuList = Globals.DataProvider.GetMenus();
            TypeDishList = Globals.DataProvider.GetTypeDishes().ToList();
            TypeDishList.Insert(0, new TypeDish { Title = "Все типы" });
        }
        private IEnumerable<Models.MenuItem> _MenuList;
        public List<TypeDish> TypeDishList { get; set; }
        public IEnumerable<Models.MenuItem> MenuList 
        { 
            get 
            {
                var Result = _MenuList;
                if (TypeDishesId > 0)
                    Result = Result.Where(d => d.TypeDishId == TypeDishesId);

                if (SearchFilter != "")
                    Result = Result.Where(
                        m => m.TitleCostR.IndexOf(SearchFilter, StringComparison.OrdinalIgnoreCase) >= 0 ||
                        m.Description.IndexOf(SearchFilter, StringComparison.OrdinalIgnoreCase) >= 0
                        );

                switch(SortType)
                {
                    case 1:
                            Result = Result.OrderBy(m => m.Title);
                            break;
                    case 2:
                        Result = Result.OrderByDescending(m => m.Title);
                        break;
                    case 3:
                        Result = Result.OrderBy(m => m.Cost);
                        break;
                    case 4:
                        Result = Result.OrderByDescending(m => m.Cost);
                        break;
                }

                return Result;
            }
            set 
            {
                _MenuList = value;
                Invalidate();
            } 
        }
        public string[] SortList { get; set; } =
        {
            "Без сортировки",
            "название по возрастанию",
            "название по убыванию",
            "цена по возрастанию",
            "цена по убыванию"
        };
        private int SortType = 0;               

        private void SortTypeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SortType = SortTypeComboBox.SelectedIndex;
            Invalidate();
        }
        public event PropertyChangedEventHandler PropertyChanged;
        private void Invalidate()
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs("MenuList"));
        }
        private string SearchFilter = "";
        private void SearchFilterTextBox_KeyUp(object sender, KeyEventArgs e)
        {
            SearchFilter = SearchFilterTextBox.Text;
            Invalidate();
        }
        private int TypeDishesId = 0;
        private void TypeDishFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TypeDishesId = (TypeDishFilter.SelectedItem as TypeDish).ID;
            Invalidate();
        }

        private void AddNewItem_Click(object sender, RoutedEventArgs e)
        {
            var NewEditWindow = new AddFood(new Models.MenuItem());
            if ((bool)NewEditWindow.ShowDialog())
            {
                MenuList = Globals.DataProvider.GetMenus();
            }
        }        

        private void MenuListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var NewEditWindow = new AddFood(MenuListView.SelectedItem as Models.MenuItem);
            if ((bool)NewEditWindow.ShowDialog())
            {                
                MenuList = Globals.DataProvider.GetMenus();
            }
        }
    }
}
