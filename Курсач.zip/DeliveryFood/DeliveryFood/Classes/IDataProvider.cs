﻿using DeliveryFood.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeliveryFood.Classes
{
    interface IDataProvider
    {
        IEnumerable<MenuItem> GetMenus();
        IEnumerable<TypeDish> GetTypeDishes();
        void SaveProduct(MenuItem ChangedItem);
    }
}
