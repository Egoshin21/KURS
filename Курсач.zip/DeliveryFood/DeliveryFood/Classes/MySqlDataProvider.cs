﻿using DeliveryFood.Models;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace DeliveryFood.Classes
{
    class MySqlDataProvider:IDataProvider
    {
        private MySqlConnection Connection;
        public MySqlDataProvider()
        {
            try
            {
                Connection = new MySqlConnection(
                    "Server=server232;Database=aegoshin;port=3306;UserId=serv232;password=123456");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public IEnumerable<MenuItem> GetMenus()
        {
            List<MenuItem> Menus = new List<MenuItem>();
            string Query = "Select * From menu";
            try
            {
                GetTypeDishes();
                Connection.Open();
                try
                {
                    MySqlCommand Command = new MySqlCommand(Query, Connection);
                    MySqlDataReader Reader = Command.ExecuteReader();
                    while(Reader.Read())
                    {
                        MenuItem NewMenuItem = new MenuItem();

                        NewMenuItem.ID = Reader.GetInt32("id");
                        NewMenuItem.Title = Reader.GetString("Nazvanie");
                        NewMenuItem.Description = Reader.GetString("Opisanie");
                        NewMenuItem.Cost = Reader.GetString("Stoimost");
                        NewMenuItem.Image = Reader.GetString("Image");
                        NewMenuItem.TypeDishId = Reader.GetInt32("TypeDishId");
                        NewMenuItem.CurrentTypeDish = GetTypeDish(Reader.GetInt32("TypeDishId"));


                        Menus.Add(NewMenuItem);
                    }
                }
                finally
                {
                    Connection.Close();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return Menus;
        }
        private List<TypeDish> TypeDishes = null;

        public IEnumerable<TypeDish> GetTypeDishes()
        {
            if(TypeDishes == null)
            {
                TypeDishes = new List<TypeDish>();
                string Query = "Select * From typedish;";
                try
                {
                    Connection.Open();
                    try
                    {
                        MySqlCommand Command = new MySqlCommand(Query, Connection);
                        MySqlDataReader Reader = Command.ExecuteReader();
                        while(Reader.Read())
                        {
                            TypeDish NewTypeDish = new TypeDish();
                            NewTypeDish.ID = Reader.GetInt32("id");
                            NewTypeDish.Title = Reader.GetString("Title");
                            TypeDishes.Add(NewTypeDish);
                        }
                    }
                    finally
                    {
                        Connection.Close();
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                
            }
            return TypeDishes;
        }
        private TypeDish GetTypeDish(int Id)
        {
            // тут заполнится список типов продукции, если он ещё пустой
            GetTypeDishes();
            return TypeDishes.Find(pt => pt.ID == Id);
        }

        public void SaveProduct(MenuItem ChangedItem)
        {
            Connection.Open();
            try
            {
                if (ChangedItem.ID == 0)
                {
                    // новый продукт - добавляем запись
                    string Query = @"INSERT INTO menu
            (Nazvanie,
            Opisanie,
            Stoimost,
            Image,
            TypeDishId)
            VALUES
            (@Title,
            @Description,
            @Cost,
            @Image,
            @TypeDishId)";

                    MySqlCommand Command = new MySqlCommand(Query, Connection);
                    Command.Parameters.AddWithValue("@Title", ChangedItem.Title);
                    Command.Parameters.AddWithValue("@Description", ChangedItem.Description);
                    Command.Parameters.AddWithValue("@Cost", ChangedItem.Cost);
                    Command.Parameters.AddWithValue("@Image", ChangedItem.Image);
                    Command.Parameters.AddWithValue("@TypeDishId",ChangedItem.CurrentTypeDish.ID);
                    
                    Command.ExecuteNonQuery();
                }
                else
                {
                    // существующий продукт - изменяем запись

                    string Query = @"UPDATE menu
            SET
            Nazvanie = @Title,
            Opisanie = @Description,
            Stoimost = @Cost,
            Image = @Image,
            TypeDishId = @TypeDishId            
            WHERE id = @ID";

                    MySqlCommand Command = new MySqlCommand(Query, Connection);
                    Command.Parameters.AddWithValue("@Title", ChangedItem.Title);
                    Command.Parameters.AddWithValue("@Description", ChangedItem.Description);
                    Command.Parameters.AddWithValue("@Cost", ChangedItem.Cost);
                    Command.Parameters.AddWithValue("@Image", ChangedItem.Image);
                    Command.Parameters.AddWithValue("@TypeDishId", ChangedItem.CurrentTypeDish.ID);
                    Command.Parameters.AddWithValue("@ID", ChangedItem.ID);
                    Command.ExecuteNonQuery();
                }
            }
            finally
            {
                Connection.Close();
            }
        }
    }
}
