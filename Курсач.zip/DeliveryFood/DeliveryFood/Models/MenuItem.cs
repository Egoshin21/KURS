﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeliveryFood.Models
{
    public class MenuItem
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Cost { get; set; }
        public string Image { get; set; }
        public int TypeDishId { get; set; }
        public TypeDish CurrentTypeDish { get; set; }
        public Uri ImagePreview
        {
            get
            {
                var imageName = Environment.CurrentDirectory + (Image ?? "");
                return System.IO.File.Exists(imageName) ? new Uri(imageName) : null;
            }
        }
        public string TitleCostR
        {
            get
            {
                return Title + "   " + Cost + "₽";
            }
        }
            
    }
}
