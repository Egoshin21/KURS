﻿using DeliveryFood.Classes;
using DeliveryFood.Models;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DeliveryFood
{
    /// <summary>
    /// Логика взаимодействия для AddFood.xaml
    /// </summary>
    public partial class AddFood : Window, INotifyPropertyChanged
    {
        public AddFood(Models.MenuItem EditItem)
        {
            InitializeComponent();
            DataContext = this;
            CurrentItem = EditItem;
            TypeDishes = Globals.DataProvider.GetTypeDishes();
        }
        public Models.MenuItem CurrentItem { get; set; }
        public IEnumerable<TypeDish> TypeDishes { get; set; }
        public string WindowName
        {
            get
            {
                return CurrentItem.ID == 0 ? "Новый элемент меню" : "Редактирование элемента";
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void ChangedImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog GetImageDialog = new OpenFileDialog();
            // задаем фильтр для выбираемых файлов
            // до символа "|" идет произвольный текст, а после него шаблоны файлов разделенные точкой с запятой
            GetImageDialog.Filter = "Файлы изображений: (*.png, *.jpg)|*.png;*.jpg";
            // чтобы не искать по всему диску задаем начальный каталог
            GetImageDialog.InitialDirectory = Environment.CurrentDirectory;
            if (GetImageDialog.ShowDialog() == true)
            {
                // перед присвоением пути к картинке обрезаем начало строки, т.к. диалог возвращает полный путь
                CurrentItem.Image = GetImageDialog.FileName.Substring(Environment.CurrentDirectory.Length);
                // обратите внимание, это другое окно и другой Invalidate, который реализуйте сами
                Invalidate();
            }
        }
        private void Invalidate()
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs("TypeDishes"));
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                
                Globals.DataProvider.SaveProduct(CurrentItem);
                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
